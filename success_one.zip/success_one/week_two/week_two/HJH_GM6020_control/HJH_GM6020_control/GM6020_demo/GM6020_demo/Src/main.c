/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp_key.h"
#include "bsp_led.h"
#include "bsp_can.h"
#include "bsp_pwm.h"
#include "pid.h"
#include "kaerman.h" 
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define voltage_compensation 10 //对速度pid滤波值后的补偿设定值

uint8_t circle_flag;//多圈记录的圈数变量
extern moto_info_t motor_info[MOTOR_MAX_NUM];//电机信息结构体
int16_t led_cnt;
int16_t real_speed;
int16_t change_current;
uint16_t real_ecd;
float real_current;
//单级pid结构体
pid_struct_t speed_motor_pid[1];
pid_struct_t ecd_motor_pid[1];
//串级结构体
pid_struct_t Cascade_speed_motor_pid[1];
pid_struct_t Cascade_ecd_motor_pid[1];

//目标变量设置
float target_speed;//原本速度目标值
float target_speed2;//加值速度目标值
float target_ecd;//编码器目标值
float turque_get;
float turque_set;
float current_set;//扭矩转为电流后的设定值
float test_data[3];//测试数组
float alpha;//一阶低通滤波权重参数
float watch_kaer;
float forward_value = 0.13;
uint8_t tail[4] = {0x00, 0x00, 0x80, 0x7f};//vofa波形调试需发送tail
int32_t my_ecd;
int32_t my_speed;
int32_t last_my_speed;
uint8_t select_num;//pid模式选择变量
uint16_t pwm_set=1550;
uint16_t pwm_angle;


//卡尔曼结构体定义//
KalmanFilter kaer;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
watch_kaer=kaer.R;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN1_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	HAL_GPIO_WritePin(GPIOH, POWER1_CTRL_Pin|POWER2_CTRL_Pin|POWER3_CTRL_Pin|POWER4_CTRL_Pin, GPIO_PIN_SET); 
	pwm_init();
	//非cubmax初始化//
	my_init();
	//初始值设定//
  Initial_value_setting();
 
  //单环时速度与角度的分别参数初始化//
  pid_init(&speed_motor_pid[0], 68, 0.35, 90, 13000, 15000); //有卡尔曼 36 1.5 90 8000 14000
  pid_init(&ecd_motor_pid[0], 11.8, 0.0025, 30, 600, 14000);//4 0.002 30 200 14000 
	
	
//	pid_init(&Cascade_speed_motor_pid[0], 25, 2, 60, 12000, 15000);//4 0.002 30 200 14000 
//	pid_init(&Cascade_ecd_motor_pid[0], 0.09, 0, 0.33, 8000, 14000);//4 0.002 30 200 14000 
	
//	pid_init(&Cascade_speed_motor_pid[0], 90, 0, 60, 12000, 15000);//4 0.002 30 200 14000 
//	pid_init(&Cascade_ecd_motor_pid[0], 0.5, 0, 0, 8000, 14000);//4 0.002 30 200 14000 
	
	pid_init(&Cascade_speed_motor_pid[0], 70, 2, 100, 12000, 15000);//4 0.002 30 200 14000 
	pid_init(&Cascade_ecd_motor_pid[0], 0.07, 0, 0.4, 8000, 14000);//4 0.002 30 200 14000 
	
  //pid_init(&torque_motor_pid[0], 0, 0, 0, 14000, 14000);//电机可通过上位机直接调电流环
  //***********END******************//
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	//主循环代码从这里开始写//
  //扭矩转电流//
	Torque_to_current();
	//速度环反馈数据滤波//
	Kalman_and_low_pass_fliter();
	//pid计算(目前都是单级)
	Individual_PID_selection();
	//发送电流can信号//
  set_motor_voltage(0,motor_info[0].set_voltage,0,0,0);
	//多圈记录//
  gimbal_ecd_count();
	//串口接收//
	HAL_UART_Receive_IT(&huart2,re_data, 3);
	//波形调试函数//
  vofa_test(target_speed2,kaer.x,motor_info[0].rotor_speed);
  //pwm控制//
//   __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, pwm_set);
//   __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, pwm_set);
//   __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, pwm_set);
//   __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, pwm_set);
	HAL_Delay(1);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 6;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
//***********my functions***********//

/**
  * @name  real_traget
  * @brief 函数用于补偿因一阶低通滤波而损失的速度值
  * @retval None
  */

float real_traget(void)
{
  // if (target_speed>=0)      target_speed2=target_speed+7;
  // else if (target_speed<0)  target_speed2=target_speed-7;
  // else if(target_speed==0)  target_speed2=0;
	target_speed2=target_speed;
  return target_speed2;
}

/**
  * @name  gimbal_ecd_count
  * @brief 将编码器值扩展为多圈而非0-8191
  * @retval None
  */

void gimbal_ecd_count(void)
{
  if(circle_flag==0)
   {
  motor_info[0].ecd0 =motor_info[0].rotor_angle;
	circle_flag=1;
   }
	if(circle_flag==1)
	{
	motor_info[0].ecd_now = (float) motor_info[0].rotor_angle;
  if((motor_info[0].ecd_now -motor_info[0].ecd_last)< -4096)
	{
	motor_info[0].ecd_round++;
	}
	if((motor_info[0].ecd_now -motor_info[0].ecd_last)> 4096)
	{
	motor_info[0].ecd_round--;
	}
	if(motor_info[0].ecd_round == 0)
	{
	motor_info[0].ecd_out= (float)((motor_info[0].rotor_angle));
	}
	if(motor_info[0].ecd_round >=1)
	{
	motor_info[0].ecd_out = (float)(((motor_info[0].ecd_round-1) *8191  + motor_info[0].rotor_angle));
	}
	if(motor_info[0].ecd_round <= (-1))
	{
	motor_info[0].ecd_out =(float)(((motor_info[0].ecd_round +1)* 8191  + (-8191 + motor_info[0].rotor_angle)));
	}
	my_ecd=motor_info[0].ecd_out;
	motor_info[0].ecd_last = motor_info[0].ecd_now;	
	} 	
}

/**
  * @name  Initial_value_setting
  * @brief 变量的初始值设定
  * @retval None
  */
void Initial_value_setting(void)
{
  target_ecd=1000;//目标角度（编码器值）
  turque_set=0.04;//目标扭矩
	target_speed=20;//目标速度（由于经过滤波后速度数值较为失真，暂无法给出具体单位）
	alpha=0.75;//低通滤波器占比参数
	select_num=2;//pid模式选择
}

/**
  * @name  my_init
  * @brief 自用函数的初始化
  * @retval None
  */

void my_init(void)
{
	//启动定时器//
//  HAL_TIM_Base_Start_IT(&htim1);
	HAL_TIM_Base_Start_IT(&htim2);
	//卡尔曼初始化
	Kalman_Init(&kaer);
	//switch on 24v power
  HAL_GPIO_WritePin(GPIOH, POWER1_CTRL_Pin|POWER2_CTRL_Pin|POWER3_CTRL_Pin|POWER4_CTRL_Pin, GPIO_PIN_SET); 
  //can滤波器初始化//	
  can_user_init(&hcan1);
}

/**
  * @name  Torque_to_current
  * @brief 扭矩值转换为电流值
  * @retval None
  */
void Torque_to_current(void)
{
  //0.741为扭矩常数，3和16384分别代表电流与ADC的对应关系（3A与14bit）
  current_set=turque_set/0.741/3*16384;
}

/**
  * @name  Kalman_and_low_pass_fliter
  * @brief 对电机反馈速度的卡尔曼和低通滤波
  * @retval None
  */

void Kalman_and_low_pass_fliter(void)
{
	motor_info[0].now_rotor_speed=alpha*motor_info[0].now_rotor_speed+(1-alpha)*motor_info[0].rotor_last_speed;
  motor_info[0].rotor_last_speed=motor_info[0].now_rotor_speed;	
  Kalman_Update(&kaer,motor_info[0].rotor_speed);
  
}

/**
  * @name  Individual_PID_selection
  * @brief 选择pid控制模式
  * 其中select_num:1->速度单环 2->角度单环 3->角度串级
  * @retval None
  */

void Individual_PID_selection(void)
{
	switch(select_num)
	{
	case 1:
	motor_info[0].set_voltage = pid_speed_calc(&speed_motor_pid[0],real_traget(), kaer.x)+ forward_value*current ;
	break;
	case 2:
	motor_info[0].set_voltage = pid_calc(&ecd_motor_pid[0], target_ecd, motor_info[0].ecd_out) ;
	break;
	case 3:
	motor_info[0].set_speed = pid_calc(&Cascade_ecd_motor_pid[0], target_ecd, motor_info[0].ecd_out);
	motor_info[0].set_voltage = pid_speed_calc(&Cascade_speed_motor_pid[0],motor_info[0].set_speed, kaer.x);
  break;
//	case 4:
//	motor_info[0].set_voltage =	current_set;
//	break;
	}
}

/**
  * @name  vofa_test
  * @brief 用于vofa+的波形调试
  * 此串口用于usart2,后续需增加串口（与接受上位机共用的一个串口）
  * @retval None
  */

void vofa_test(float a,float b,float c)
{
  //数组赋值//		
	test_data[0]=a;
  test_data[1]=b;
  test_data[2]=motor_info[0].rotor_speed;
	//以下串口发送为vofa调试，需要时消除注释//
  HAL_UART_Transmit(&huart2,(uint8_t*)test_data,sizeof(test_data),10);
  HAL_UART_Transmit(&huart2,tail,sizeof(tail),10);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
