#include "kaerman.h"  

#define DIM 1 // 状态维度  

// 初始化卡尔曼滤波器  
void Kalman_Init(KalmanFilter *kf) {  
    // 状态初始值  
    kf->x = 0;  
    // 协方差初始值  
    kf->P = 1;  

    // 状态转移矩阵  
    kf->F = 1;  
    // 观测矩阵  
    kf->H = 1;  
    // 过程噪声协方差  
    kf->Q = 0.01;  
    // 测量噪声协方差  
    kf->R = 0.23;  
}  

// 执行卡尔曼滤波  
void Kalman_Update(KalmanFilter *kf, float z) {  
    // 状态预测  
    float x_pred;  
    x_pred = kf->F * kf->x;  

    // 协方差预测  
    float P_pred;  
    P_pred = kf->F * kf->P * kf->F + kf->Q;  

    // 计算卡尔曼增益  
    float S = P_pred * kf->H + kf->R; // 预测测量的误差  
    float K = P_pred * kf->H / S; // 卡尔曼增益  

    // 状态更新  
    kf->x = x_pred + K * (z - (kf->H * x_pred));  

    // 协方差更新  
    kf->P = (1 - K * kf->H) * P_pred;  
}  